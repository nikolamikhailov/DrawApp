package com.example.drawapp.base

interface Item {
}