package com.example.drawapp.base

interface Event {
}